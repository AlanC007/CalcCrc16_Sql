﻿namespace Crc16_Lib_App
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.tbGTIN = new System.Windows.Forms.TextBox();
            this.tbCrcResults = new System.Windows.Forms.TextBox();
            this.tbCompanyCode = new System.Windows.Forms.TextBox();
            this.lblCompanyCode = new System.Windows.Forms.Label();
            this.tbPartNumber = new System.Windows.Forms.TextBox();
            this.lblpartnumber = new System.Windows.Forms.Label();
            this.tbLotNumber = new System.Windows.Forms.TextBox();
            this.lblLotCode = new System.Windows.Forms.Label();
            this.lblDateCode = new System.Windows.Forms.Label();
            this.tbDate = new System.Windows.Forms.TextBox();
            this.lblGTINFull = new System.Windows.Forms.Label();
            this.btnPrintLabel = new System.Windows.Forms.Button();
            this.lblQty = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.listBox_Printers = new System.Windows.Forms.ListBox();
            this.tbYear = new System.Windows.Forms.TextBox();
            this.tbMonth = new System.Windows.Forms.TextBox();
            this.tbDay = new System.Windows.Forms.TextBox();
            this.lblyear = new System.Windows.Forms.Label();
            this.lblMonth = new System.Windows.Forms.Label();
            this.lblDay = new System.Windows.Forms.Label();
            this.lblLongDate = new System.Windows.Forms.Label();
            this.tbLongDate = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.lblQty)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(8, 291);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(182, 30);
            this.button1.TabIndex = 0;
            this.button1.Text = "Generate Voice Pick Code";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbGTIN
            // 
            this.tbGTIN.Location = new System.Drawing.Point(8, 264);
            this.tbGTIN.MaxLength = 999;
            this.tbGTIN.Name = "tbGTIN";
            this.tbGTIN.ReadOnly = true;
            this.tbGTIN.Size = new System.Drawing.Size(273, 20);
            this.tbGTIN.TabIndex = 1;
            // 
            // tbCrcResults
            // 
            this.tbCrcResults.Location = new System.Drawing.Point(67, 327);
            this.tbCrcResults.Name = "tbCrcResults";
            this.tbCrcResults.Size = new System.Drawing.Size(55, 20);
            this.tbCrcResults.TabIndex = 2;
            // 
            // tbCompanyCode
            // 
            this.tbCompanyCode.Location = new System.Drawing.Point(8, 46);
            this.tbCompanyCode.Name = "tbCompanyCode";
            this.tbCompanyCode.ReadOnly = true;
            this.tbCompanyCode.Size = new System.Drawing.Size(100, 20);
            this.tbCompanyCode.TabIndex = 3;
            // 
            // lblCompanyCode
            // 
            this.lblCompanyCode.AutoSize = true;
            this.lblCompanyCode.Location = new System.Drawing.Point(8, 27);
            this.lblCompanyCode.Name = "lblCompanyCode";
            this.lblCompanyCode.Size = new System.Drawing.Size(79, 13);
            this.lblCompanyCode.TabIndex = 4;
            this.lblCompanyCode.Text = "Company Code";
            // 
            // tbPartNumber
            // 
            this.tbPartNumber.Location = new System.Drawing.Point(8, 88);
            this.tbPartNumber.Name = "tbPartNumber";
            this.tbPartNumber.Size = new System.Drawing.Size(161, 20);
            this.tbPartNumber.TabIndex = 5;
            this.tbPartNumber.TextChanged += new System.EventHandler(this.tbPartNumber_TextChanged);
            // 
            // lblpartnumber
            // 
            this.lblpartnumber.AutoSize = true;
            this.lblpartnumber.Location = new System.Drawing.Point(8, 70);
            this.lblpartnumber.Name = "lblpartnumber";
            this.lblpartnumber.Size = new System.Drawing.Size(66, 13);
            this.lblpartnumber.TabIndex = 6;
            this.lblpartnumber.Text = "Part Number";
            // 
            // tbLotNumber
            // 
            this.tbLotNumber.Location = new System.Drawing.Point(8, 137);
            this.tbLotNumber.Name = "tbLotNumber";
            this.tbLotNumber.Size = new System.Drawing.Size(100, 20);
            this.tbLotNumber.TabIndex = 7;
            this.tbLotNumber.TextChanged += new System.EventHandler(this.tbLotNumber_TextChanged);
            // 
            // lblLotCode
            // 
            this.lblLotCode.AutoSize = true;
            this.lblLotCode.Location = new System.Drawing.Point(8, 119);
            this.lblLotCode.Name = "lblLotCode";
            this.lblLotCode.Size = new System.Drawing.Size(62, 13);
            this.lblLotCode.TabIndex = 8;
            this.lblLotCode.Text = "Lot Number";
            // 
            // lblDateCode
            // 
            this.lblDateCode.AutoSize = true;
            this.lblDateCode.Location = new System.Drawing.Point(8, 204);
            this.lblDateCode.Name = "lblDateCode";
            this.lblDateCode.Size = new System.Drawing.Size(90, 13);
            this.lblDateCode.TabIndex = 10;
            this.lblDateCode.Text = "Date  (YYMMDD)";
            // 
            // tbDate
            // 
            this.tbDate.Location = new System.Drawing.Point(8, 220);
            this.tbDate.Name = "tbDate";
            this.tbDate.ReadOnly = true;
            this.tbDate.Size = new System.Drawing.Size(100, 20);
            this.tbDate.TabIndex = 9;
            // 
            // lblGTINFull
            // 
            this.lblGTINFull.AutoSize = true;
            this.lblGTINFull.Location = new System.Drawing.Point(8, 248);
            this.lblGTINFull.Name = "lblGTINFull";
            this.lblGTINFull.Size = new System.Drawing.Size(97, 13);
            this.lblGTINFull.TabIndex = 11;
            this.lblGTINFull.Text = "Value To Generate";
            // 
            // btnPrintLabel
            // 
            this.btnPrintLabel.Location = new System.Drawing.Point(8, 501);
            this.btnPrintLabel.Name = "btnPrintLabel";
            this.btnPrintLabel.Size = new System.Drawing.Size(273, 42);
            this.btnPrintLabel.TabIndex = 12;
            this.btnPrintLabel.Text = "Print Label";
            this.btnPrintLabel.UseVisualStyleBackColor = true;
            this.btnPrintLabel.Click += new System.EventHandler(this.btnPrintLabel_Click);
            // 
            // lblQty
            // 
            this.lblQty.Location = new System.Drawing.Point(8, 373);
            this.lblQty.Name = "lblQty";
            this.lblQty.Size = new System.Drawing.Size(120, 20);
            this.lblQty.TabIndex = 13;
            this.lblQty.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 354);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "How Many Labels?";
            // 
            // listBox_Printers
            // 
            this.listBox_Printers.FormattingEnabled = true;
            this.listBox_Printers.Location = new System.Drawing.Point(8, 400);
            this.listBox_Printers.Name = "listBox_Printers";
            this.listBox_Printers.Size = new System.Drawing.Size(182, 95);
            this.listBox_Printers.TabIndex = 15;
            this.listBox_Printers.SelectedIndexChanged += new System.EventHandler(this.listBox_Printers_SelectedIndexChanged);
            // 
            // tbYear
            // 
            this.tbYear.Location = new System.Drawing.Point(8, 181);
            this.tbYear.Name = "tbYear";
            this.tbYear.Size = new System.Drawing.Size(46, 20);
            this.tbYear.TabIndex = 16;
            this.tbYear.TextChanged += new System.EventHandler(this.tbYear_TextChanged);
            // 
            // tbMonth
            // 
            this.tbMonth.Location = new System.Drawing.Point(64, 181);
            this.tbMonth.Name = "tbMonth";
            this.tbMonth.Size = new System.Drawing.Size(46, 20);
            this.tbMonth.TabIndex = 17;
            this.tbMonth.TextChanged += new System.EventHandler(this.tbMonth_TextChanged);
            // 
            // tbDay
            // 
            this.tbDay.Location = new System.Drawing.Point(116, 181);
            this.tbDay.Name = "tbDay";
            this.tbDay.Size = new System.Drawing.Size(46, 20);
            this.tbDay.TabIndex = 18;
            this.tbDay.TextChanged += new System.EventHandler(this.tbDay_TextChanged);
            // 
            // lblyear
            // 
            this.lblyear.AutoSize = true;
            this.lblyear.Location = new System.Drawing.Point(8, 164);
            this.lblyear.Name = "lblyear";
            this.lblyear.Size = new System.Drawing.Size(36, 13);
            this.lblyear.TabIndex = 19;
            this.lblyear.Text = "YEAR";
            // 
            // lblMonth
            // 
            this.lblMonth.AutoSize = true;
            this.lblMonth.Location = new System.Drawing.Point(64, 163);
            this.lblMonth.Name = "lblMonth";
            this.lblMonth.Size = new System.Drawing.Size(47, 13);
            this.lblMonth.TabIndex = 20;
            this.lblMonth.Text = "MONTH";
            // 
            // lblDay
            // 
            this.lblDay.AutoSize = true;
            this.lblDay.Location = new System.Drawing.Point(125, 163);
            this.lblDay.Name = "lblDay";
            this.lblDay.Size = new System.Drawing.Size(29, 13);
            this.lblDay.TabIndex = 21;
            this.lblDay.Text = "DAY";
            // 
            // lblLongDate
            // 
            this.lblLongDate.AutoSize = true;
            this.lblLongDate.Location = new System.Drawing.Point(125, 204);
            this.lblLongDate.Name = "lblLongDate";
            this.lblLongDate.Size = new System.Drawing.Size(135, 13);
            this.lblLongDate.TabIndex = 23;
            this.lblLongDate.Text = "LongDate (MM/DD/YYYY)";
            // 
            // tbLongDate
            // 
            this.tbLongDate.Location = new System.Drawing.Point(116, 220);
            this.tbLongDate.Name = "tbLongDate";
            this.tbLongDate.ReadOnly = true;
            this.tbLongDate.Size = new System.Drawing.Size(144, 20);
            this.tbLongDate.TabIndex = 22;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(197, 300);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(84, 20);
            this.textBox1.TabIndex = 24;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(297, 555);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblLongDate);
            this.Controls.Add(this.tbLongDate);
            this.Controls.Add(this.lblDay);
            this.Controls.Add(this.lblMonth);
            this.Controls.Add(this.lblyear);
            this.Controls.Add(this.tbDay);
            this.Controls.Add(this.tbMonth);
            this.Controls.Add(this.tbYear);
            this.Controls.Add(this.listBox_Printers);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblQty);
            this.Controls.Add(this.btnPrintLabel);
            this.Controls.Add(this.lblGTINFull);
            this.Controls.Add(this.lblDateCode);
            this.Controls.Add(this.tbDate);
            this.Controls.Add(this.lblLotCode);
            this.Controls.Add(this.tbLotNumber);
            this.Controls.Add(this.lblpartnumber);
            this.Controls.Add(this.tbPartNumber);
            this.Controls.Add(this.lblCompanyCode);
            this.Controls.Add(this.tbCompanyCode);
            this.Controls.Add(this.tbCrcResults);
            this.Controls.Add(this.tbGTIN);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "GS1 Label Printing";
            ((System.ComponentModel.ISupportInitialize)(this.lblQty)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbGTIN;
        private System.Windows.Forms.TextBox tbCrcResults;
        private System.Windows.Forms.TextBox tbCompanyCode;
        private System.Windows.Forms.Label lblCompanyCode;
        private System.Windows.Forms.TextBox tbPartNumber;
        private System.Windows.Forms.Label lblpartnumber;
        private System.Windows.Forms.TextBox tbLotNumber;
        private System.Windows.Forms.Label lblLotCode;
        private System.Windows.Forms.Label lblDateCode;
        private System.Windows.Forms.TextBox tbDate;
        private System.Windows.Forms.Label lblGTINFull;
        private System.Windows.Forms.Button btnPrintLabel;
        private System.Windows.Forms.NumericUpDown lblQty;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBox_Printers;
        private System.Windows.Forms.TextBox tbYear;
        private System.Windows.Forms.TextBox tbMonth;
        private System.Windows.Forms.TextBox tbDay;
        private System.Windows.Forms.Label lblyear;
        private System.Windows.Forms.Label lblMonth;
        private System.Windows.Forms.Label lblDay;
        private System.Windows.Forms.Label lblLongDate;
        private System.Windows.Forms.TextBox tbLongDate;
        private System.Windows.Forms.TextBox textBox1;
    }
}

