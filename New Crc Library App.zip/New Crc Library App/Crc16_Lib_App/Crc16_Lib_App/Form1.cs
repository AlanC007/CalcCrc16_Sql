﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using SunCRC.CRCGeneric;
using SunCRC.CrcTest;
using SunCRC.CrcTest.Crc8Test;
using SunCRC.CrcTest.Crc16Test;
using SunCRC.CrcTest.Crc32Test;
using SunCRC.CrcTest.Crc64Test;
using SunCRC.CrcGeneric;
using SunCRC.CRCGeneric.BaseGeneric;
using SunCRC.Crc.Crc8;
using SunCRC.Crc.Crc16;
using SunCRC.Crc;


namespace Crc16_Lib_App
{

    public partial class Form1 : Form
    {
        static string LotNumber;
        static string Partnumber;
        static string date;
        static string longDate;
        static string CompanyCode;
        static string vpcMSB;
        static string vpcLSB;
        [DllImport("Winspool.drv")]
        private static extern bool SetDefaultPrinter(string printerName);

        private void listAllPrinters()
        {
            foreach (var item in PrinterSettings.InstalledPrinters)
            {
                this.listBox_Printers.Items.Add(item.ToString());
            }

        }

        public Form1()
        {
            AppDomain.CurrentDomain.AssemblyResolve += new ResolveEventHandler(CurrentDomain_AssemblyResolve);
            // ResolveEventArgs args = new ResolveEventArgs("SunCrc.dll");
            // CurrentDomain_AssemblyResolve( this, args);
            InitializeComponent();
            listAllPrinters();
            tbCompanyCode.Text = "000" + "9711";
            CompanyCode = tbCompanyCode.Text;
            DateTime vStrToday = new DateTime();
            String Year;
            String vStrMonth;
            String vStrDay;
            vStrToday = Convert.ToDateTime(DateTime.Today.ToLongDateString());
            Year = Convert.ToString(vStrToday.Year);
            vStrMonth = Convert.ToString(vStrToday.Month);
            vStrDay = Convert.ToString(vStrToday.Day);
            Year = Year.Substring(2);
            longDate = vStrToday.Month + "/" + vStrToday.Day + "/" + vStrToday.Year;
            // Test the Month to see if it is only a Single Digit
            if (vStrMonth.Length == 1)
            {
                vStrMonth = 0 + vStrMonth;
            }
            // Test the Day to see if it is only a Single Digit
            if (vStrDay.Length == 1)
            {
                vStrDay = 0 + vStrDay;
            }

            // tbDate.Text = Convert.ToString(Year) + Convert.ToString(vStrMonth) + Convert.ToString(vStrDay);

        }
        System.Reflection.Assembly CurrentDomain_AssemblyResolve(object sender, ResolveEventArgs args)
        {
            string dllName = args.Name.Contains(',') ? args.Name.Substring(0, args.Name.IndexOf(',')) : args.Name.Replace(".dll", "");

            dllName = dllName.Replace(".", "_");

            if (dllName.EndsWith("_resources")) return null;

            System.Resources.ResourceManager rm = new System.Resources.ResourceManager(GetType().Namespace + ".Properties.Resources", System.Reflection.Assembly.GetExecutingAssembly());

            byte[] bytes = (byte[])rm.GetObject(dllName);

            return System.Reflection.Assembly.Load(bytes);
        }
        #region Button Click Events
        private void button1_Click(object sender, EventArgs e)
        {
            tbGTIN.Text = tbCompanyCode.Text + tbPartNumber.Text + tbLotNumber.Text + tbDate.Text;
            ushort ResultCrc;
            string vpcResults;
            string value = tbGTIN.Text;
            byte[] a = new byte[value.Length];
            char[] b = new char[value.Length];
            b = value.ToCharArray();
            byte[] GtinBytes = new byte[value.Length];


            System.Collections.IEnumerable collection = Enumerable.Range(100, 10);

            foreach (var ch in b.OfType<object>().Select((x, i) => new { x, i }))
            {
                int index = ch.i;
                try
                {
                    byte _GtinBytes = Convert.ToByte(ch.x);
                    GtinBytes[index] = _GtinBytes;

                }

                catch (OverflowException)
                {
                    Console.WriteLine("Unable to convert u+{0} to a byte.",
                                      Convert.ToInt16(ch).ToString("X4"));
                }

            }

            Crc16Model getVPCModel = new Crc16Model(0x8005, 0x0, 0x0, true, true);
            Crc16 getVPCDB = new Crc16(getVPCModel);
            ResultCrc = getVPCDB.Compute(GtinBytes);
            tbCrcResults.Text = ResultCrc.ToString();
            // Code for Left and Right String Chars()
            // vpcResults = Convert.ToString(ResultCrc).Substring(4);
            // vpcMSB = vpcResults.Substring(2);
            // vpcLSB = "";

        }

        private void btnPrintLabel_Click(object sender, EventArgs e)
        {
            string vStrLabel;

            ZebraLabels labelData = new ZebraLabels();
            string content1 = labelData.SpoonLabel();
            vStrLabel = content1;

            PrintDocument p = new PrintDocument();
            p.PrintPage += delegate (object sender1, PrintPageEventArgs e1)
            {
                e1.Graphics.DrawString(vStrLabel, new Font("Times New Roman", 12), new SolidBrush(Color.Black), new RectangleF(0, 0, p.DefaultPageSettings.PrintableArea.Width, p.DefaultPageSettings.PrintableArea.Height));

            };
            try
            {
                p.Print();
            }
            catch (Exception ex)
            {
                throw new Exception("Exception Occured While Printing", ex);
            }
        }
        #endregion
        #region Printer managrement
        public class MyPrintManager
        {
            public static PrinterSettings MyPrinterSettings = new PrinterSettings();

            public static string Default_PrinterName
            {
                get
                {
                    return MyPrinterSettings.PrinterName;
                }
                set
                {
                    MyPrinterSettings.DefaultPageSettings.PrinterSettings.PrinterName = value;
                    MyPrinterSettings.PrinterName = value;
                    SetDefaultPrinter(value);
                }
            }
        }
        #endregion
        #region Label Context data
        public class ZebraLabels
        {
            public string SpoonLabel()
            {
                string vStrLabel;
                char backslash = '\\';
                char slash1 = Convert.ToChar(Char.ConvertFromUtf32(92));
                double slash = Char.GetNumericValue(slash1);
                int unicode = 92;
                char character = (char)unicode;
                string text = "\\";
                int txtLen = text.Length;
                vStrLabel = Char.ConvertFromUtf32(94) + "XA";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "LT50";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "MMT,N";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "PW1200^LL1800";

                //^FX Top section Lot Value min font size = 1/2" or 36 point
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FX PL400003 Label";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "CFB,36";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO50,25^ADN50,50^FDLot#^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO100,85^GB700,100,2,B,4^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO300,110^ADN50,50^FD" + LotNumber + "^FS";
                //^ FX Second section with Product Data
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,250^ADN60,60^FDSpoon, PP, Black^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FX DW Item #";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,350^FDPL400003^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FX Chipotle #";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,400^FD65088-024^FS";

                //^FX Third section Package Information
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,500^FDKeep in Cool Dry Place^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,550^FDNet Wt 14.5 lbs, 6.59 Kg^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,600^FDProduct of USA^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO775,600^FDTotal Qty:1500^FS";

                //^FX 4th Section Production Date
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO800,275^FDProduction^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO875,315^FDDate^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO775,365^GB325,75,2,B,0^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO800,375^FD" + @longDate + "^FS";

                //^ FX Company Information
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,675^FDD&W Fine Pack^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,725^FD1372 old North Laurens Road^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,775^FDFountain Inn,SC  29644^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FX 5th Section Production Date Barcodes and Such";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,850^BY3,2.5,5^BCN,200,N,N,N,N^FD>;01" + CompanyCode + Partnumber + "11" + date + "10" + LotNumber + "^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,1075^ADN30,30^FD(01)" + CompanyCode + Partnumber + "(11)" + date + "(10)" + LotNumber + "^FS";

                //^FX Voice Code Calculations
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FT975,1525^A0N,163,158^FH" + @backslash + "^FD46^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FT875,1525^A0N,83,83^FH" + @backslash + "^FD13^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "LRY^FO850,1350^GB300,0,200^FS^LRN";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "XZ";
                return vStrLabel;
            }
            public string KnifeLabel()
            {
                string vStrLabel;
                vStrLabel = Char.ConvertFromUtf32(94) + "XA";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "LT50";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "MMT,N";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "PW1200^LL1800";

                //^FX Top section Lot Value min font size = 1/2" or 36 point
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FX PL400003 Label";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "CFB,36";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO50,25^ADN50,50^FDLot#^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO100,85^GB700,100,2,B,4^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO300,110^ADN50,50^FD" + LotNumber + "^FS";
                //^ FX Second section with Product Data
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,250^ADN60,60^FDKnife, PP, Black^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FX DW Item #";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,350^FDPL400002^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FX Chipotle #";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,400^FD65089-021^FS";

                //^FX Third section Package Information
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,500^FDKeep in Cool Dry Place^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,550^FDNet Wt 18 lbs, 8.17 Kg^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,600^FDProduct of USA^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO775,600^FDTotal Qty: 1500^FS";

                //^FX 4th Section Production Date
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO800,275^FDProduction^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO875,315^FDDate^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO775,365^GB325,75,2,B,0^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO800,375^FD" + longDate + "^FS";

                //^ FX Company Information
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,675^FDD&W Fine Pack^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,725^FD1372 old North Laurens Road^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,775^FDFountain Inn,SC  29644^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FX 5th Section Production Date Barcodes and Such";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,850^BY3,2.5,5^BCN,200,N,N,N,N^FD>;01" + CompanyCode + Partnumber + "11" + longDate + "10" + LotNumber + "^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FO25,1075^ADN30,30^FD(01)" + CompanyCode + Partnumber + "(11)" + longDate + "(10)" + LotNumber + "^FS";

                //^FX Voice Code Calculations
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FT975,1525^A0N,163,158^FH" + Char.ConvertFromUtf32(92) + "^FD46^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "FT875,1525^A0N,83,83^FH" + Char.ConvertFromUtf32(92) + "^FD13^FS";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "LRY^FO850,1350^GB300,0,200^FS^LRN";
                vStrLabel = vStrLabel + Char.ConvertFromUtf32(94) + "XZ";
                return vStrLabel;
            }
        }
        #endregion
        #region Screen object's Value Change Events
        private void listBox_Printers_SelectedIndexChanged(object sender, EventArgs e)
        {

            string pname = this.listBox_Printers.SelectedItem.ToString();
            MyPrintManager.Default_PrinterName = pname;
        }
        private void tbPartNumber_TextChanged(object sender, EventArgs e)
        {
            Partnumber = tbPartNumber.Text;
            tbCrcResults.Text = "";
            // Handle The Text Value limits here
        }

        private void tbLotNumber_TextChanged(object sender, EventArgs e)
        {
            // Handle The Text Value limits here
            LotNumber = tbLotNumber.Text;
            tbCrcResults.Text = "";
        }


        private void tbYear_TextChanged(object sender, EventArgs e)
        {
            if (tbYear.Text.Length > 1)
            {
                date = tbYear.Text.Substring(2) + tbMonth.Text + tbDay.Text;
                longDate = tbMonth.Text + "/" + tbDay.Text + "/" + tbYear.Text;
                tbLongDate.Text = longDate;
                tbDate.Text = date;
                tbCrcResults.Text = "";
            }
        }

        private void tbMonth_TextChanged(object sender, EventArgs e)
        {
            date = tbYear.Text.Substring(2) + tbMonth.Text + tbDay.Text;
            longDate = tbMonth.Text + "/" + tbDay.Text + "/" + tbYear.Text;
            tbLongDate.Text = longDate;
            tbDate.Text = date;
            tbCrcResults.Text = "";
        }

        private void tbDay_TextChanged(object sender, EventArgs e)
        {
            date = tbYear.Text.Substring(2) + tbMonth.Text + tbDay.Text;
            longDate = tbMonth.Text + "/" + tbDay.Text + "/" + tbYear.Text;
            tbLongDate.Text = longDate;
            tbDate.Text = date;
            tbCrcResults.Text = "";
        }
        #endregion

    }
}
